-- Q3. check total number of rows

select count(*) as Total_Number_Of_Rows
from dataset