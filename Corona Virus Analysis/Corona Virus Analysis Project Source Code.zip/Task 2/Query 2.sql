-- Q2. If NULL values are present, update them with zeros for all columns.

UPDATE dataset
SET Province = IFNULL(Province, 0),
    Country_Region = IFNULL(Country_Region, 0),
    Latitude = IFNULL(Latitude, 0),
    Longitude = IFNULL(Longitude, 0),
    Date = IFNULL(Date, 0),
    Confirmed = IFNULL(Confirmed, 0),
    Deaths = IFNULL(Deaths, 0),
    Recovered = IFNULL(Recovered, 0)
    WHERE Province is null OR
      Country_Region is null OR
      Latitude is null OR
      Longitude is null OR
      Date is null OR
      Confirmed is null OR
      Deaths is null OR
      Recovered is null;
