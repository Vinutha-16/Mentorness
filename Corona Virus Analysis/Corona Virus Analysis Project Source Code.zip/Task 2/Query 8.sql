-- Q8. Find minimum values for confirmed, deaths, recovered per year

   SELECT 
    EXTRACT(YEAR FROM Date) AS years,
    MIN(Confirmed) AS min_confirmed,
    MIN(Deaths) AS min_deaths,
    MIN(Recovered) AS min_recovered
FROM dataset
GROUP BY EXTRACT(YEAR FROM Date)
ORDER BY years; 
    