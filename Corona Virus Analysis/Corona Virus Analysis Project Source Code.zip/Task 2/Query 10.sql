-- Q10. The total number of case of confirmed, deaths, recovered each month

SELECT
    EXTRACT(YEAR FROM Date) AS Year,
    EXTRACT(MONTH FROM Date) AS Month,
    SUM(Confirmed) AS TotalConfirmed,
    SUM(Deaths) AS TotalDeaths,
    SUM(Recovered) AS TotalRecovered
FROM dataset
GROUP BY Year, Month
ORDER BY Year, Month;