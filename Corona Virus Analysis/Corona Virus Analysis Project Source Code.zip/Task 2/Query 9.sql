-- Q9. Find maximum values of confirmed, deaths, recovered per year

	SELECT 
    EXTRACT(YEAR FROM Date) AS years,
    MAX(Confirmed) AS max_confirmed,
    MAX(Deaths) AS max_deaths,
    MAX(Recovered) AS max_recovered
FROM dataset
GROUP BY EXTRACT(YEAR FROM Date)
ORDER BY years;