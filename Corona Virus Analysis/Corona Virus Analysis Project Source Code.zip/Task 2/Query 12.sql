-- Q12. Check how corona virus spread out with respect to death case per month
--      (Eg.: total confirmed cases, their average, variance & STDEV )

SELECT 
    COUNT(Deaths) as TotalDeathCases,
    AVG(Deaths) as AvgDeathCases,
    VARIANCE(Deaths) as VarianceDeaths,
    STDDEV(Deaths) as StdDevDeaths
FROM dataset;