-- Q15. Find Country having lowest number of the death case

SELECT Country_Region, MIN(Deaths) AS Lowest_Death_Cases
FROM dataset
GROUP BY Country_Region
ORDER BY Lowest_Death_Cases