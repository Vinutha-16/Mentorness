-- Q11. Check how corona virus spread out with respect to confirmed case
--      (Eg.: total confirmed cases, their average, variance & STDEV )

SELECT 
    COUNT(Confirmed) as TotalConfirmedCases,
    AVG(Confirmed) as AvgConfirmedCases,
    VARIANCE(Confirmed) as VarianceConfirmed,
    STDDEV(Confirmed) as StdDevConfirmed
  FROM dataset;