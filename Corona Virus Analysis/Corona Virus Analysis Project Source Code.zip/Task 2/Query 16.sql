-- Q16. Find top 5 countries having highest recovered case

SELECT Country_Region, MAX(Recovered) AS Highest_Recovered_Cases
FROM dataset
GROUP BY Country_Region
ORDER BY Highest_Recovered_Cases DESC
LIMIT 5;