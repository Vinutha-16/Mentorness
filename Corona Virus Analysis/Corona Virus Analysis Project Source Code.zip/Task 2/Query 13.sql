-- Q13. Check how corona virus spread out with respect to recovered case
--      (Eg.: total confirmed cases, their average, variance & STDEV )

SELECT 
    COUNT(Recovered) as TotalRecoveredCases,
    AVG(Recovered) as AvgRecoveredCases,
    VARIANCE(Recovered) as VarianceRecovered,
    STDDEV(Recovered) as StdDevRecovered
FROM dataset;