-- Q7. Find most frequent value for confirmed, deaths, recovered each month 

WITH AggregatedData AS (
    SELECT
        EXTRACT(YEAR FROM Date) AS Year,
        EXTRACT(MONTH FROM Date) AS Month,
        Confirmed, Deaths, Recovered,
        ROW_NUMBER() OVER (PARTITION BY EXTRACT(YEAR FROM Date), EXTRACT(MONTH FROM Date), Confirmed ORDER BY COUNT(*) DESC) AS Confirmed_Rank,
        ROW_NUMBER() OVER (PARTITION BY EXTRACT(YEAR FROM Date), EXTRACT(MONTH FROM Date), Deaths ORDER BY COUNT(*) DESC) AS Deaths_Rank,
        ROW_NUMBER() OVER (PARTITION BY EXTRACT(YEAR FROM Date), EXTRACT(MONTH FROM Date), Recovered ORDER BY COUNT(*) DESC) AS Recovered_Rank
    FROM dataset
    GROUP BY Year, Month, Confirmed, Deaths, Recovered
)
SELECT Year, Month, MostFrequentConfirmed, MostFrequentDeaths, MostFrequentRecovered
FROM (
    SELECT
        Year, Month, MAX(Confirmed) AS MostFrequentConfirmed, MAX(Deaths) AS MostFrequentDeaths, MAX(Recovered) AS MostFrequentRecovered
    FROM AggregatedData
    WHERE
        Confirmed_Rank = 1
        AND Deaths_Rank = 1
        AND Recovered_Rank = 1
    GROUP BY Year, Month
) AS MostFrequentData
ORDER BY Year, Month;