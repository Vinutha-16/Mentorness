-- Q14. Find Country having highest number of the Confirmed case

SELECT Country_Region, MAX(Confirmed) AS Highest_Confirmed_Cases
FROM dataset
GROUP BY Country_Region
ORDER BY Highest_Confirmed_Cases DESC
LIMIT 1;
