-- Q1. Write a code to check NULL values
	
      select * 
      from dataset
      where Province is null OR
      Country_Region is null OR
      Latitude is null OR
      Longitude is null OR
      Date is null OR
      Confirmed is null OR
      Deaths is null OR
      Recovered is null 