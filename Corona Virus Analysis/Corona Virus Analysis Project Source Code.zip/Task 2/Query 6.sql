-- Q6. Find monthly average for confirmed, deaths, recovered

SELECT 
	YEAR(Date) as Year,
    MONTH(Date) as Month,
    AVG(Confirmed) as Avg_confirmed,
    AVG(Deaths) as Avg_deaths,
    AVG(Recovered) as Avg_recovered
FROM dataset
GROUP BY YEAR(Date), MONTH(Date)
ORDER BY YEAR(Date), MONTH(Date)

