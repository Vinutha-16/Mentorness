-- Q4. Check what is start_date and end_date

SELECT MIN(date) AS start_date, MAX(date) AS end_date
FROM dataset;