-- Q5. Number of month present in dataset

SELECT COUNT(DISTINCT MONTH(Date)) AS Number_of_Months
FROM dataset; 